NO_CHANGE = object()
"""A sentinel object used in update APIs to indicate that the field does not need to be updated."""
