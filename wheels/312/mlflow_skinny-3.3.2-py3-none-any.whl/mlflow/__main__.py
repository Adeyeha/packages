from mlflow.cli import cli

cli.main()
