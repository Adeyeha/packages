def _get_latest_metric_version():
    return "v1"


def _get_default_model():
    return "openai:/gpt-4"
