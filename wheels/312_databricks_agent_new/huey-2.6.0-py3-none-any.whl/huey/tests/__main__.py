import sys
import unittest

from huey.tests import *


if __name__ == '__main__':
    unittest.main(argv=sys.argv)
