from unitycatalog.ai.core.version import VERSION

__version__ = VERSION
