# Update this when publishing a new version
VERSION = "0.64"
