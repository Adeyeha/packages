from unitycatalog.ai.langchain.version import VERSION

__version__ = VERSION
