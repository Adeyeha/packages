"""langchain-core version information and utilities."""

VERSION = "1.2.7"
